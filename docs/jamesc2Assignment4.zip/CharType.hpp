/*********************************************************************
** Author: Collin James
** Date: 11/8/15
** Description: An enumerator to be used with Creatures.
*********************************************************************/

enum CharType { NONE=0, GOBLIN, BARB, SHADOW, REPTILE, BLUEMEN };